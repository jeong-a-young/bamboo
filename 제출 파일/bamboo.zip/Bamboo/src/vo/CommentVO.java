package vo;

import java.sql.Date;

public class CommentVO {

	private int postId;
	private int commentId;
	private String commentWriter;
	private String commentSet;
	private String commentContents;
	private Date commentTime;
	
	public CommentVO() {
		super();
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public String getCommentWriter() {
		return commentWriter;
	}

	public void setCommentWriter(String commentWriter) {
		this.commentWriter = commentWriter;
	}

	public String getCommentSet() {
		return commentSet;
	}

	public void setCommentSet(String commentSet) {
		this.commentSet = commentSet;
	}

	public String getCommentContents() {
		return commentContents;
	}

	public void setCommentContents(String commentContents) {
		this.commentContents = commentContents;
	}

	public Date getCommentTime() {
		return commentTime;
	}

	public void setCommentTime(Date commentTime) {
		this.commentTime = commentTime;
	}
	
}